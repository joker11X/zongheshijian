package com.neusoft.elm.view;
import  com.neusoft.elm.po.Admin;
public interface AdminView {
    public Admin login();
}
